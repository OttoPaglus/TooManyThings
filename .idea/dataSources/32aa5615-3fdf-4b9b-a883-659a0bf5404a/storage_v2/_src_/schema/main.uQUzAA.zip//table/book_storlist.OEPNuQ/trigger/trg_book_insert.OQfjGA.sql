CREATE TRIGGER trg_book_insert
            AFTER INSERT ON book_storlist
            BEGIN
                UPDATE book_storlist
                SET createtime = DATETIME('now', '+8 hours')
                WHERE rowid = NEW.rowid;
            END;

